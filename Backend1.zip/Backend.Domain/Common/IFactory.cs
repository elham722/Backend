namespace Backend.Domain.Common
{
    public interface IFactory
    {
        // Marker interface for factories
    }
} 