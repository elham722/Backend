namespace Backend.Domain.Common
{
    public interface IDomainService
    {
        // Marker interface for domain services
    }
} 