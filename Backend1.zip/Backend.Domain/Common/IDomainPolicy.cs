namespace Backend.Domain.Common
{
    public interface IDomainPolicy
    {
        // Marker interface for domain policies
    }
} 