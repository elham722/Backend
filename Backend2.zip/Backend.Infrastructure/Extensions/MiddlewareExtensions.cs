using Microsoft.AspNetCore.Builder;

namespace Backend.Infrastructure.Extensions
{
    public static class MiddlewareExtensions
    {
      
    }
} 